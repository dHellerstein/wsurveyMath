22 April 2021.
wSurvey\Math : a set of math and statistical functions

A set of math and statistical php functions, including sorts and merges.

Inludes:
 a) Binomial random variable generation functions.
    For both "standard" and "reverse" binomial  (reverse= generate rates given observed #events and #successs)

 b) Merge two sorted matrices
 c) Search for a matching value in a sorted matrix
 d) Golden rule search for maximum value in a single peaked function
 e) Sort a matrix on a column
 f) log gamma (N!) 
 g) Weighted mean and variance
... more later!

These features are supported in seperate .php files. See the several .txt files for documentation 




